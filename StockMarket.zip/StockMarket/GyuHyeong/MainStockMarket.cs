﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StockMarket
{
    public partial class MainStockMarket : Form
    {
        public static string[] mystock = new string[3];
        public string[] buy_stock = new string[2];
        public string[] view_stock_array = new string[5];
        string[] stock_array = new string[5];
        DataBase db = RefDataBase.db;
        NotAttacker c_NotA;
        Normal c_Nor;
        Attacker c_A;
        User user;

        string[] stocks = new string[] { "호랑이", "너구리", "사자", "고양이", "매미", "강아지",
                "사슴", "고라니", "지렁이", "노루", "백호", "펭귄", "금붕어", "니모", "가오리", "매", "독수리", "참새",
                "까마귀", "비둘기", "닭", "병아리", "고슴도치", "상어", "하이에나", "기러기", "매기", "파이썬", "자바", "씨" };

        string id;
        public MainStockMarket(string id,string na)
        {
            c_NotA = new NotAttacker();
            c_Nor = new Normal();
            c_A = new Attacker();
            user = new User();
            this.id = id;
            InitializeComponent();
            name.Text = "" + db.GetName(na);

            // trade groupbox 내의 속성 조절
            show_price_label.Text = "" + view_stock_array[1];
            trade_stock_name.Text = "" + view_stock_array[0];
            user_money_label.Text = "" + db.GetClientMoney(id);// 유저 머니.
            trade_stock_total.Text = "0";

            stockview.View = View.Details;
            stockview.GridLines = true;
            stockview.FullRowSelect = true;
            stockview.Sorting = SortOrder.Ascending;

            string[] items = new string[5];
            items[2] = "-";
            items[3] = "-";
            items[4] = "-";
          

            for(int i = 0; i < 30; i++)
            {
                int count = 0;
                foreach(var a in db.stockDic1[stocks[i]])
                {
                    count++;   
                }
                items[0] = stocks[i];
                items[1] = db.stockDic1[stocks[i]][count-1].ToString();
                ListViewItem lvItem = new ListViewItem(items);
                stockview.Items.Add(lvItem);
            }


        }
        public MainStockMarket()
        {
            InitializeComponent();
            // trade groupbox 내의 속성 조절
            show_price_label.Text = "" + view_stock_array[1];
            trade_stock_name.Text = "" + view_stock_array[0];
            user_money_label.Text = "" + db.GetClientMoney(id);// 유저 머니.
            trade_stock_total.Text = "" + (int.Parse(trade_stock_amount.Value.ToString()) * int.Parse(trade_text_price.Text)).ToString();
        }

        private void joinform_next_exit_Click(object sender, EventArgs e) // X 버튼
        {
            this.Close();
        }

        private void MainStockMarket_Load(object sender, EventArgs e)
        {
            
        }

        private void stock_timer_Tick(object sender, EventArgs e) // 1초에 30분
        {
            db.ChangeTime();
            int[] time = new int[5];
            time = db.GetTime();
            label2.Text = "" + time[0];
            label4.Text = "" + time[1];
            label6.Text = "" + time[2];
            label8.Text = "" + time[3];
            label9.Text = "" + time[4];


            //쓰레드 -> 컴퓨터 유저 3명이 동시에 사게 하기 위해서
            Thread th1 = new Thread(ComputerBuy1);
            Thread th2 = new Thread(ComputerBuy2);
            Thread th3 = new Thread(ComputerBuy3);
            th1.Start();
            th2.Start();
            th3.Start();

            stockview.Update();
            mystockview.Update();
        }

        void ComputerBuy1()
        {
            buy_stock = c_A.Attack();
            if (buy_stock[0] != "못삼")
                Update(buy_stock[0], int.Parse(buy_stock[1]));
        }

        void ComputerBuy2()
        {
            buy_stock = c_Nor.Nor();
            if (buy_stock[0] != "못삼")
                Update(buy_stock[0], int.Parse(buy_stock[1]));
        }

        void ComputerBuy3()
        {
            buy_stock = c_NotA.NotA();
            if (buy_stock[0] != "못삼")
                Update(buy_stock[0], int.Parse(buy_stock[1]));
        }

        private void stockview_MouseClick(object sender, MouseEventArgs e) // substockmarket 폼 띄우기
        {
        }

        private void trade_stock_buy_Click(object sender, EventArgs e)
        {
            // 주식 사는 매서드        
            string[] info = new string[3];
            user.BuyStock(name.Text,trade_stock_name.Text,int.Parse(trade_stock_amount.ToString()),int.Parse(trade_text_price.Text),int.Parse(user_money.Text));
            info[0] = trade_stock_name.Text;
            info[1] = trade_text_price.Text;
            info[2] = trade_stock_amount.ToString();
            ListViewItem lvitem = new ListViewItem(info);
            mystockview.Items.Add(lvitem);
        }

        private void trade_stock_sele_Click(object sender, EventArgs e)
        {
            trade_stock_amount.Maximum = trade_stock_amount.Value;
            // 파는 이벤트
            mystockview.SelectedItems[0].Remove();
            MessageBox.Show(trade_stock_name + "를 " + trade_stock_amount.Value + "주 매도하여 " + trade_stock_total.Text + "원 버셨습니다.");
        }

        private void mystockview_MouseClick(object sender, MouseEventArgs e)
        {

        }
        void Update(string sName,int money)
        {
            CheckForIllegalCrossThreadCalls = false;
            int index = 100;
            stock_array = db.GetStockInfo(sName, money);
           
            if (stock_array[4] == "2")
            {
                stock_array[4] = "▲";

            }
            else if (stock_array[4] == "0")
            {
                stock_array[4] = "▼";
            }
            else if (stock_array[4] == "1")
            {
                stock_array[4] = "-";
            }
            // ListView 생성
            stockview.View = View.Details;
            stockview.GridLines = true;
            stockview.FullRowSelect = true;
            stockview.Sorting = SortOrder.Ascending;



            ListViewItem lvitem = new ListViewItem(stock_array);


            //stockview.Items.RemoveAt(index);
            stockview.Items.Add(lvitem);
                     
        }

        private void stockview_SelectedIndexChanged(object sender, EventArgs e)
        {
            string a;

            SubStockMarket substockmarket = new SubStockMarket(stockview.Items[stockview.FocusedItem.Index].SubItems[0].Text, stockview.Items[stockview.FocusedItem.Index].SubItems[1].Text);
            trade_stock_name.Text = stockview.Items[stockview.FocusedItem.Index].SubItems[0].Text;
            show_price_label.Text = stockview.Items[stockview.FocusedItem.Index].SubItems[1].Text;
            user_money_label.Text = buy_stock[1];
            a = (int.Parse(trade_stock_amount.Value.ToString()) * int.Parse(stockview.Items[stockview.FocusedItem.Index].SubItems[1].Text)).ToString();
            trade_stock_total.Text = a;

            substockmarket.Show();
        }

        private void save_Click(object sender, EventArgs e)
        {
            db.Save();
            this.Close();
        }

        private void trade_stock_amount_ValueChanged(object sender, EventArgs e)
        {
            int price = int.Parse(trade_text_price.Text) * int.Parse(trade_stock_amount.ToString());
            trade_stock_total.Text = price.ToString();
        }

        private void trade_text_price_TextChanged(object sender, EventArgs e)
        {
        }
    }
}
