﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StockMarket
{
    public partial class SubStockMarket : Form
    {
        DataBase db = RefDataBase.db;
        int[] time = new int[5];
        string sName, price;

        public SubStockMarket()
        {
            InitializeComponent();
        }

        public SubStockMarket(string sName, string price)
        {
            InitializeComponent();
            this.sName = sName;
            this.price = price;
        }

        private void SubStockMarket_Load(object sender, EventArgs e)
        {
            string[] oldstockprice = new string[2];
            int count = 0;
            while(db.GetOldStocksPrice(sName)[count] == 0)
            {
                count++;
            }
            oldstockprice[0] = sName;
            oldstockprice[1] = db.GetOldStocksPrice(sName)[count].ToString();

            for(int i = 0; i < 5; i++)
            { 
                ListViewItem lvItem = new ListViewItem(oldstockprice);
                stock_history.Items.Add(lvItem);
            }
        }

        private void stock_timer_sub_Tick(object sender, EventArgs e)
        {
            stock_history.Update();
            chart1.Update();
        }

        /*private void SubStockMarket_Load(object sender, EventArgs e)
        {
            
            int[] oldstockprice = new int[30];
            int count = 0;
            while(db.GetOldStocksPrice("id")==0)// 종목 이름 매서드) == 0)
            {
                count++;
            }
            int[] oldprice = new int[5];
            oldprice[0] = db.GetOldStocksPrice();

            
            
            stock_history.View = View.Details;
        }
        */
    }
}
