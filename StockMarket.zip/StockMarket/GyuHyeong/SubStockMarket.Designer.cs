﻿namespace StockMarket
{
    partial class SubStockMarket
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.stock_history = new System.Windows.Forms.ListView();
            this.stock_info_name = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.stock_info_price = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.stock_timer_sub = new System.Windows.Forms.Timer(this.components);
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.stock_history);
            this.groupBox1.Location = new System.Drawing.Point(6, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(771, 382);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Stock";
            // 
            // stock_history
            // 
            this.stock_history.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.stock_history.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.stock_info_name,
            this.stock_info_price});
            this.stock_history.Location = new System.Drawing.Point(6, 24);
            this.stock_history.Name = "stock_history";
            this.stock_history.Size = new System.Drawing.Size(765, 358);
            this.stock_history.TabIndex = 0;
            this.stock_history.UseCompatibleStateImageBehavior = false;
            this.stock_history.View = System.Windows.Forms.View.Details;
            // 
            // stock_info_name
            // 
            this.stock_info_name.Text = "NAME";
            this.stock_info_name.Width = 291;
            // 
            // stock_info_price
            // 
            this.stock_info_price.Text = "PRICE";
            this.stock_info_price.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.stock_info_price.Width = 469;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.chart1);
            this.groupBox2.Location = new System.Drawing.Point(6, 400);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(771, 441);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Chart";
            // 
            // chart1
            // 
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(6, 24);
            this.chart1.Name = "chart1";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.chart1.Series.Add(series1);
            this.chart1.Size = new System.Drawing.Size(758, 411);
            this.chart1.TabIndex = 0;
            this.chart1.Text = "chart1";
            // 
            // stock_timer_sub
            // 
            this.stock_timer_sub.Enabled = true;
            this.stock_timer_sub.Interval = 5000;
            this.stock_timer_sub.Tick += new System.EventHandler(this.stock_timer_sub_Tick);
            // 
            // SubStockMarket
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(782, 853);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "SubStockMarket";
            this.Text = "SubStockMarket";
            this.Load += new System.EventHandler(this.SubStockMarket_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.ListView stock_history;
        public System.Windows.Forms.ColumnHeader stock_info_name;
        public System.Windows.Forms.ColumnHeader stock_info_price;
        private System.Windows.Forms.Timer stock_timer_sub;
    }
}